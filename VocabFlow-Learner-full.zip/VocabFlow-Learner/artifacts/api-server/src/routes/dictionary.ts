import { Router, type IRouter } from "express";
import {
  dictionaryProvider,
  DictionaryProviderError,
} from "../services/dictionary";

const router: IRouter = Router();
const WORD_PATTERN = /^[A-Za-z]+(?:['’-][A-Za-z]+)*$/;

router.get("/dictionary", async (req, res) => {
  const word = req.query.word;
  if (
    typeof word !== "string" ||
    word.trim().length === 0 ||
    word.trim().length > 60 ||
    !WORD_PATTERN.test(word.trim())
  ) {
    res.status(400).json({
      code: "INVALID_WORD",
      message: "Hãy nhập một từ tiếng Anh hợp lệ.",
    });
    return;
  }

  try {
    res.json(await dictionaryProvider.searchWord(word.trim()));
  } catch (error) {
    if (error instanceof DictionaryProviderError) {
      res.status(error.status).json({ code: error.code, message: error.message });
      return;
    }
    res.status(503).json({
      code: "UNAVAILABLE",
      message: "Nguồn từ điển tạm thời không khả dụng.",
    });
  }
});

export default router;
