const DICTIONARY_API_BASE =
  "https://api.dictionaryapi.dev/api/v2/entries/en";
const DICTIONARY_API_SOURCE = "https://dictionaryapi.dev/";
const REQUEST_TIMEOUT_MS = 8_000;

export interface DictionarySense {
  partOfSpeech?: string;
  definition: string;
  vietnameseMeaning?: string;
  example?: string;
  exampleTranslation?: string;
  synonyms?: string[];
}

export interface DictionaryPronunciation {
  ipa?: string;
  accent?: string;
  audioUrl: string;
  sourceUrl: string;
  licenseName: string;
  licenseUrl: string;
}

export interface DictionaryEntry {
  word: string;
  ipa?: string;
  vietnameseMeanings?: string[];
  senses: DictionarySense[];
  pronunciations?: DictionaryPronunciation[];
  sourceName: string;
  sourceUrls: string[];
  licenseName?: string;
  licenseUrl?: string;
}

export interface DictionaryLookupResult {
  query: string;
  found: boolean;
  entry?: DictionaryEntry;
}

export interface DictionaryProvider {
  searchWord(query: string): Promise<DictionaryLookupResult>;
}

export class DictionaryProviderError extends Error {
  constructor(
    message: string,
    readonly status: 429 | 502 | 503,
    readonly code: "RATE_LIMITED" | "INVALID_RESPONSE" | "UNAVAILABLE",
  ) {
    super(message);
    this.name = "DictionaryProviderError";
  }
}

type JsonRecord = Record<string, unknown>;

function isRecord(value: unknown): value is JsonRecord {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function nonEmptyString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function httpsUrl(value: unknown): string | undefined {
  const candidate = nonEmptyString(value);
  if (!candidate) return undefined;
  try {
    const parsed = new URL(candidate);
    return parsed.protocol === "https:" ? parsed.toString() : undefined;
  } catch {
    return undefined;
  }
}

function stringList(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((item): item is string =>
    typeof item === "string" && item.trim().length > 0,
  ).map((item) => item.trim()))];
}

function accentFromAudioUrl(audioUrl: string): string | undefined {
  const match = audioUrl.match(/-(uk|us|au)(?:[._-]|$)/i);
  if (!match) return undefined;
  return { uk: "Anh", us: "Mỹ", au: "Úc" }[match[1].toLowerCase()];
}

function normalizeResponse(
  query: string,
  payload: unknown,
): DictionaryLookupResult {
  if (!Array.isArray(payload)) {
    throw new DictionaryProviderError(
      "Nguồn từ điển trả dữ liệu không hợp lệ.",
      502,
      "INVALID_RESPONSE",
    );
  }

  const rawEntries = payload.filter(isRecord);
  if (rawEntries.length === 0) return { query, found: false };

  const senses: DictionarySense[] = [];
  const sourceUrls = new Set<string>();
  const pronunciations = new Map<string, DictionaryPronunciation>();
  let ipa: string | undefined;
  let licenseName: string | undefined;
  let licenseUrl: string | undefined;
  let word = query;

  for (const rawEntry of rawEntries) {
    word = nonEmptyString(rawEntry.word) ?? word;

    const rawLicense = isRecord(rawEntry.license) ? rawEntry.license : undefined;
    licenseName ??= nonEmptyString(rawLicense?.name);
    licenseUrl ??= httpsUrl(rawLicense?.url);

    for (const source of stringList(rawEntry.sourceUrls)) {
      const sourceUrl = httpsUrl(source);
      if (sourceUrl) sourceUrls.add(sourceUrl);
    }

    const rawPhonetics = Array.isArray(rawEntry.phonetics)
      ? rawEntry.phonetics.filter(isRecord)
      : [];
    ipa ??=
      nonEmptyString(rawEntry.phonetic) ??
      rawPhonetics.map((item) => nonEmptyString(item.text)).find(Boolean);

    for (const phonetic of rawPhonetics) {
      const audioUrl = httpsUrl(phonetic.audio);
      const sourceUrl = httpsUrl(phonetic.sourceUrl);
      const rawAudioLicense = isRecord(phonetic.license)
        ? phonetic.license
        : undefined;
      const audioLicenseName = nonEmptyString(rawAudioLicense?.name);
      const audioLicenseUrl = httpsUrl(rawAudioLicense?.url);
      if (
        audioUrl &&
        sourceUrl &&
        audioLicenseName &&
        audioLicenseUrl &&
        !pronunciations.has(audioUrl)
      ) {
        pronunciations.set(audioUrl, {
          ...(nonEmptyString(phonetic.text)
            ? { ipa: nonEmptyString(phonetic.text) }
            : {}),
          ...(accentFromAudioUrl(audioUrl)
            ? { accent: accentFromAudioUrl(audioUrl) }
            : {}),
          audioUrl,
          sourceUrl,
          licenseName: audioLicenseName,
          licenseUrl: audioLicenseUrl,
        });
      }
    }

    const meanings = Array.isArray(rawEntry.meanings)
      ? rawEntry.meanings.filter(isRecord)
      : [];
    for (const meaning of meanings) {
      const partOfSpeech = nonEmptyString(meaning.partOfSpeech);
      const definitions = Array.isArray(meaning.definitions)
        ? meaning.definitions.filter(isRecord)
        : [];
      for (const definition of definitions) {
        const text = nonEmptyString(definition.definition);
        if (!text) continue;
        const vietnameseMeaning = nonEmptyString(definition.vietnameseMeaning);
        const example = nonEmptyString(definition.example);
        const exampleTranslation = nonEmptyString(
          definition.exampleTranslation,
        );
        const synonyms = [
          ...stringList(definition.synonyms),
          ...stringList(meaning.synonyms),
        ];
        senses.push({
          ...(partOfSpeech ? { partOfSpeech } : {}),
          definition: text,
          ...(vietnameseMeaning ? { vietnameseMeaning } : {}),
          ...(example ? { example } : {}),
          ...(exampleTranslation ? { exampleTranslation } : {}),
          ...(synonyms.length ? { synonyms: [...new Set(synonyms)] } : {}),
        });
      }
    }
  }

  if (senses.length === 0) return { query, found: false };
  if (sourceUrls.size === 0) sourceUrls.add(DICTIONARY_API_SOURCE);

  const vietnameseMeanings = [
    ...new Set(
      senses
        .map((sense) => sense.vietnameseMeaning)
        .filter((value): value is string => Boolean(value)),
    ),
  ];
  return {
    query,
    found: true,
    entry: {
      word,
      ...(ipa ? { ipa } : {}),
      ...(vietnameseMeanings.length ? { vietnameseMeanings } : {}),
      senses,
      ...(pronunciations.size
        ? { pronunciations: [...pronunciations.values()] }
        : {}),
      sourceName: "Free Dictionary API (dữ liệu Wiktionary)",
      sourceUrls: [...sourceUrls],
      ...(licenseName ? { licenseName } : {}),
      ...(licenseUrl ? { licenseUrl } : {}),
    },
  };
}

export function createFreeDictionaryProvider(
  fetcher: typeof fetch = fetch,
): DictionaryProvider {
  return {
    async searchWord(query: string): Promise<DictionaryLookupResult> {
      const normalized = query.trim();
      if (!/^[A-Za-z]+(?:['’-][A-Za-z]+)*$/.test(normalized)) {
        throw new DictionaryProviderError(
          "Hãy nhập một từ tiếng Anh hợp lệ.",
          502,
          "INVALID_RESPONSE",
        );
      }

      let response: Response;
      try {
        response = await fetcher(
          `${DICTIONARY_API_BASE}/${encodeURIComponent(normalized)}`,
          {
            headers: { accept: "application/json" },
            signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
          },
        );
      } catch {
        throw new DictionaryProviderError(
          "Không thể kết nối nguồn từ điển.",
          503,
          "UNAVAILABLE",
        );
      }

      if (response.status === 404) return { query: normalized, found: false };
      if (response.status === 429) {
        throw new DictionaryProviderError(
          "Nguồn từ điển đang giới hạn lượt tra cứu.",
          429,
          "RATE_LIMITED",
        );
      }
      if (!response.ok) {
        throw new DictionaryProviderError(
          "Nguồn từ điển tạm thời không khả dụng.",
          503,
          "UNAVAILABLE",
        );
      }

      let payload: unknown;
      try {
        payload = await response.json();
      } catch {
        throw new DictionaryProviderError(
          "Nguồn từ điển trả dữ liệu không hợp lệ.",
          502,
          "INVALID_RESPONSE",
        );
      }
      return normalizeResponse(normalized, payload);
    },
  };
}

export const dictionaryProvider = createFreeDictionaryProvider();
