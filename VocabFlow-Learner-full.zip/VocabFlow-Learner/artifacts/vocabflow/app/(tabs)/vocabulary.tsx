import React, { useMemo, useState } from 'react';
import {
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import {
  AppPage,
  IconButton,
  Panel,
  ScreenTitle,
  WordRow,
} from '@/components/VocabUI';

type FilterValue = 'all' | 'new' | 1 | 2 | 3 | 4 | 5;

const filterOptions: { value: FilterValue; label: string }[] = [
  { value: 'all', label: 'Tất cả' },
  { value: 'new', label: 'Mới' },
  { value: 1, label: 'Cấp 1' },
  { value: 2, label: 'Cấp 2' },
  { value: 3, label: 'Cấp 3' },
  { value: 4, label: 'Cấp 4' },
  { value: 5, label: 'Cấp 5' },
];

function normalize(value: string) {
  return value.toLocaleLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

export default function VocabularyScreen() {
  const colors = useColors();
  const { words, deleteWord } = useVocab();
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState<FilterValue>('all');

  const filteredWords = useMemo(() => {
    const search = normalize(query.trim());
    return [...words]
      .filter((word) => {
        const matchesSearch =
          !search ||
          normalize(word.english).includes(search) ||
          normalize(word.meaning).includes(search) ||
          normalize(word.example).includes(search);
        const matchesFilter =
          filter === 'all' ||
          (filter === 'new' ? word.reviewCount === 0 : word.masteryLevel === filter);
        return matchesSearch && matchesFilter;
      })
      .sort((a, b) => a.english.localeCompare(b.english));
  }, [filter, query, words]);

  function confirmDelete(id: string, english: string) {
    Alert.alert(
      'Xóa từ vựng?',
      `Từ “${english}” sẽ bị xóa khỏi sổ và không thể khôi phục.`,
      [
        { text: 'Giữ lại', style: 'cancel' },
        {
          text: 'Xóa từ',
          style: 'destructive',
          onPress: () => deleteWord(id),
        },
      ],
    );
  }

  return (
    <AppPage>
      <ScreenTitle
        title="Sổ từ vựng"
        subtitle={`${words.length} từ đã lưu`}
        trailing={
          <IconButton
            icon="plus"
            label="Thêm từ mới"
            testID="vocabulary-add-word"
            onPress={() => router.push('/word-form')}
            color={colors.primary}
          />
        }
      />

      <View
        style={[
          styles.searchBox,
          { backgroundColor: colors.card, borderColor: colors.border },
        ]}
      >
        <Feather name="search" size={18} color={colors.mutedForeground} />
        <TextInput
          accessibilityLabel="Tìm từ vựng"
          testID="vocabulary-search"
          value={query}
          onChangeText={setQuery}
          placeholder="Tìm từ tiếng Anh hoặc nghĩa…"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          returnKeyType="search"
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {query ? (
          <IconButton
            icon="x"
            label="Xóa nội dung tìm kiếm"
            onPress={() => setQuery('')}
            color={colors.mutedForeground}
          />
        ) : null}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
      >
        {filterOptions.map((option) => {
          const selected = filter === option.value;
          return (
            <Pressable
              key={String(option.value)}
              accessibilityRole="button"
              accessibilityState={{ selected }}
              onPress={() => setFilter(option.value)}
              style={({ pressed }) => [
                styles.filterChip,
                {
                  backgroundColor: selected ? colors.foreground : colors.card,
                  borderColor: selected ? colors.foreground : colors.border,
                  opacity: pressed ? 0.72 : 1,
                },
              ]}
            >
              <Text
                style={[
                  styles.filterText,
                  { color: selected ? colors.background : colors.mutedForeground },
                ]}
              >
                {option.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {filteredWords.length ? (
        <View style={styles.wordList}>
          {filteredWords.map((word) => (
            <WordRow
              key={word.id}
              word={word}
              onPress={() =>
                router.push({ pathname: '/word-form', params: { wordId: word.id } })
              }
              onDelete={() => confirmDelete(word.id, word.english)}
            />
          ))}
        </View>
      ) : (
        <Panel style={styles.emptyPanel}>
          <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
            <Feather
              name={query ? 'search' : 'book'}
              size={22}
              color={colors.secondaryForeground}
            />
          </View>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            {query || filter !== 'all' ? 'Không tìm thấy từ phù hợp' : 'Sổ từ còn trống'}
          </Text>
          <Text style={[styles.emptyCopy, { color: colors.mutedForeground }]}>
            {query || filter !== 'all'
              ? 'Thử từ khóa khác hoặc chọn bộ lọc khác.'
              : 'Thêm từ tiếng Anh, nghĩa và ví dụ để bắt đầu.'}
          </Text>
          {!query && filter === 'all' ? (
            <Pressable
              accessibilityRole="button"
              onPress={() => router.push('/word-form')}
              style={({ pressed }) => [styles.addLink, { opacity: pressed ? 0.7 : 1 }]}
            >
              <Text style={[styles.addLinkText, { color: colors.primary }]}>
                Thêm từ đầu tiên
              </Text>
              <Feather name="arrow-right" size={15} color={colors.primary} />
            </Pressable>
          ) : null}
        </Panel>
      )}
    </AppPage>
  );
}

const styles = StyleSheet.create({
  searchBox: { minHeight: 52, borderWidth: 1, borderRadius: 16, paddingHorizontal: 14, flexDirection: 'row', alignItems: 'center', gap: 10 },
  searchInput: { flex: 1, minHeight: 50, fontSize: 14, fontFamily: 'Inter_400Regular' },
  filters: { flexDirection: 'row', gap: 8, paddingRight: 20 },
  filterChip: { minHeight: 35, borderRadius: 20, borderWidth: 1, paddingHorizontal: 13, alignItems: 'center', justifyContent: 'center' },
  filterText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  wordList: { gap: 9 },
  emptyPanel: { alignItems: 'center', paddingVertical: 28 },
  emptyIcon: { width: 54, height: 54, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontSize: 18, textAlign: 'center', fontFamily: 'Inter_700Bold' },
  emptyCopy: { fontSize: 13, lineHeight: 20, textAlign: 'center', fontFamily: 'Inter_400Regular' },
  addLink: { flexDirection: 'row', alignItems: 'center', gap: 7, paddingTop: 5 },
  addLinkText: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
});
