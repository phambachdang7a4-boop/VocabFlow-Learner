import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import { AppPage, Panel, ScreenTitle } from '@/components/VocabUI';

const goalOptions = [5, 10, 15, 20, 30];

export default function SettingsScreen() {
  const colors = useColors();
  const { dailyGoal, setDailyGoal, words, persistenceError } = useVocab();

  return (
    <AppPage>
      <ScreenTitle
        title="Cài đặt"
        subtitle="Điều chỉnh nhịp học phù hợp với bạn."
      />

      <Panel>
        <View style={styles.settingHeader}>
          <View style={[styles.settingIcon, { backgroundColor: colors.accent }]}>
            <Feather name="target" size={18} color={colors.accentForeground} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              Mục tiêu mỗi ngày
            </Text>
            <Text style={[styles.settingDescription, { color: colors.mutedForeground }]}>
              Số lượt ôn thẻ bạn muốn hoàn thành
            </Text>
          </View>
        </View>
        <View style={styles.goalOptions}>
          {goalOptions.map((goal) => {
            const selected = dailyGoal === goal;
            return (
              <Pressable
                key={goal}
                accessibilityRole="button"
                accessibilityState={{ selected }}
                accessibilityLabel={`Đặt mục tiêu ${goal} lượt mỗi ngày`}
                testID={`goal-${goal}`}
                onPress={() => setDailyGoal(goal)}
                style={({ pressed }) => [
                  styles.goalButton,
                  {
                    backgroundColor: selected ? colors.foreground : colors.background,
                    borderColor: selected ? colors.foreground : colors.border,
                    opacity: pressed ? 0.75 : 1,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.goalNumber,
                    { color: selected ? colors.background : colors.foreground },
                  ]}
                >
                  {goal}
                </Text>
              </Pressable>
            );
          })}
        </View>
        <Text style={[styles.goalCaption, { color: colors.mutedForeground }]}>
          lượt ôn mỗi ngày
        </Text>
      </Panel>

      <Panel>
        <View style={styles.settingHeader}>
          <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="smartphone" size={18} color={colors.secondaryForeground} />
          </View>
          <View style={styles.settingText}>
            <Text style={[styles.settingTitle, { color: colors.foreground }]}>
              Lưu trữ trên thiết bị
            </Text>
            <Text style={[styles.settingDescription, { color: colors.mutedForeground }]}>
              Từ vựng và tiến độ được lưu cục bộ.
            </Text>
          </View>
        </View>
        <View style={[styles.storageStatus, { backgroundColor: colors.secondary }]}>
          <Feather
            name={persistenceError ? 'alert-circle' : 'check-circle'}
            size={16}
            color={persistenceError ? colors.destructive : colors.secondaryForeground}
          />
          <Text
            style={[
              styles.storageText,
              { color: persistenceError ? colors.destructive : colors.secondaryForeground },
            ]}
          >
            {persistenceError ? 'Có vấn đề khi lưu' : `${words.length} từ trong bộ nhớ`}
          </Text>
        </View>
        {persistenceError ? (
          <Text style={[styles.errorText, { color: colors.destructive }]}>
            {persistenceError}
          </Text>
        ) : null}
      </Panel>

      <Panel style={styles.aboutPanel}>
        <View style={[styles.brandIcon, { backgroundColor: colors.primary }]}>
          <Feather name="book-open" size={20} color={colors.primaryForeground} />
        </View>
        <Text style={[styles.aboutTitle, { color: colors.foreground }]}>VocabFlow</Text>
        <Text style={[styles.aboutCopy, { color: colors.mutedForeground }]}>
          Một nhịp học từ vựng vừa vặn mỗi ngày.
        </Text>
        <View style={[styles.divider, { backgroundColor: colors.border }]} />
        <View style={styles.infoRow}>
          <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Phiên bản</Text>
          <Text style={[styles.infoValue, { color: colors.foreground }]}>1.0.0</Text>
        </View>
        <View style={styles.infoRow}>
          <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Ngôn ngữ</Text>
          <Text style={[styles.infoValue, { color: colors.foreground }]}>Tiếng Việt</Text>
        </View>
      </Panel>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  settingHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  settingIcon: { width: 38, height: 38, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  settingText: { flex: 1, gap: 4 },
  settingTitle: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  settingDescription: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  goalOptions: { flexDirection: 'row', justifyContent: 'space-between', gap: 8, paddingTop: 5 },
  goalButton: { width: 48, height: 44, borderWidth: 1, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  goalNumber: { fontSize: 14, fontFamily: 'Inter_700Bold' },
  goalCaption: { fontSize: 11, fontFamily: 'Inter_400Regular' },
  storageStatus: { minHeight: 40, borderRadius: 13, paddingHorizontal: 12, flexDirection: 'row', alignItems: 'center', gap: 8 },
  storageText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  errorText: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_500Medium' },
  aboutPanel: { alignItems: 'center', paddingVertical: 22 },
  brandIcon: { width: 46, height: 46, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  aboutTitle: { fontSize: 18, fontFamily: 'Inter_700Bold' },
  aboutCopy: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  divider: { height: 1, width: '100%', marginVertical: 6 },
  infoRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 3 },
  infoLabel: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  infoValue: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
});
