import React, { useMemo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import {
  isSameLocalDay,
  MASTERY_LABELS,
} from '@/constants/vocabulary';
import {
  AppPage,
  Panel,
  ProgressBar,
  ScreenTitle,
} from '@/components/VocabUI';

const weekDayLabels = ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'];

export default function StatisticsScreen() {
  const colors = useColors();
  const { words, reviews, dailyGoal } = useVocab();
  const now = Date.now();
  const todayCount = reviews.filter((review) =>
    isSameLocalDay(review.reviewedAt, now),
  ).length;
  const learnedCount = words.filter((word) => word.reviewCount > 0).length;
  const masteredCount = words.filter((word) => word.masteryLevel >= 5).length;

  const weekData = useMemo(() => {
    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date();
      date.setHours(0, 0, 0, 0);
      date.setDate(date.getDate() - (6 - index));
      const count = reviews.filter((review) =>
        isSameLocalDay(review.reviewedAt, date.getTime()),
      ).length;
      return { date, count };
    });
  }, [reviews]);
  const maximumWeekCount = Math.max(1, ...weekData.map((day) => day.count));

  const masteryRows = [1, 2, 3, 4, 5, 6].map((level) => ({
    level,
    count: words.filter((word) => word.masteryLevel === level).length,
  }));
  const masteryColor = (level: number) => {
    if (level <= 2) return colors.accentForeground;
    if (level <= 4) return colors.secondaryForeground;
    return colors.primary;
  };

  return (
    <AppPage>
      <ScreenTitle
        title="Thống kê"
        subtitle="Nhìn lại từng bước tiến của bạn."
      />

      <Panel style={styles.todayPanel}>
        <View style={styles.todayHeader}>
          <View>
            <Text style={[styles.panelEyebrow, { color: colors.mutedForeground }]}>
              HÔM NAY
            </Text>
            <Text style={[styles.todayCount, { color: colors.foreground }]}>
              {todayCount}
              <Text style={[styles.todayUnit, { color: colors.mutedForeground }]}>
                {' '}lượt ôn
              </Text>
            </Text>
          </View>
          <View style={[styles.targetIcon, { backgroundColor: colors.accent }]}>
            <Feather name="target" size={20} color={colors.accentForeground} />
          </View>
        </View>
        <ProgressBar progress={(todayCount / dailyGoal) * 100} />
        <Text style={[styles.helper, { color: colors.mutedForeground }]}>
          Mục tiêu: {dailyGoal} lượt mỗi ngày
        </Text>
      </Panel>

      <View style={styles.summaryRow}>
        <Panel style={styles.summaryCard}>
          <Text style={[styles.summaryNumber, { color: colors.foreground }]}>
            {words.length}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
            từ trong sổ
          </Text>
        </Panel>
        <Panel style={styles.summaryCard}>
          <Text style={[styles.summaryNumber, { color: colors.foreground }]}>
            {learnedCount}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
            đã ôn ít nhất một lần
          </Text>
        </Panel>
        <Panel style={styles.summaryCard}>
          <Text style={[styles.summaryNumber, { color: colors.primary }]}>
            {masteredCount}
          </Text>
          <Text style={[styles.summaryLabel, { color: colors.mutedForeground }]}>
            cấp độ 4–5
          </Text>
        </Panel>
      </View>

      <Panel>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          Nhịp học 7 ngày
        </Text>
        <Text style={[styles.helper, { color: colors.mutedForeground }]}>
          Số lượt đánh giá thẻ mỗi ngày
        </Text>
        <View style={styles.chart}>
          {weekData.map((day, index) => {
            const height = day.count ? Math.max(10, (day.count / maximumWeekCount) * 86) : 4;
            return (
              <View key={day.date.toISOString()} style={styles.chartDay}>
                <Text style={[styles.chartCount, { color: colors.mutedForeground }]}>
                  {day.count || ''}
                </Text>
                <View style={styles.chartTrack}>
                  <View
                    style={[
                      styles.chartBar,
                      {
                        height,
                        backgroundColor:
                          index === 6 ? colors.primary : colors.secondaryForeground,
                        opacity: day.count ? 1 : 0.28,
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.chartLabel, { color: colors.mutedForeground }]}>
                  {weekDayLabels[day.date.getDay()]}
                </Text>
              </View>
            );
          })}
        </View>
      </Panel>

      <Panel>
        <View style={styles.masteryHeader}>
          <View style={styles.masteryTitleBlock}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Mức độ ghi nhớ
            </Text>
            <Text style={[styles.helper, { color: colors.mutedForeground }]}>
              Cấp độ theo đánh giá gần nhất
            </Text>
          </View>
          <Feather name="bar-chart-2" size={19} color={colors.primary} />
        </View>
        <View style={styles.masteryList}>
          {masteryRows.map(({ level, count }) => {
            const percent = words.length ? (count / words.length) * 100 : 0;
            return (
              <View key={level} style={styles.masteryRow}>
                <View style={styles.masteryLabel}>
                  <View
                    style={[
                      styles.levelDot,
                      { backgroundColor: masteryColor(level) },
                    ]}
                  />
                  <Text style={[styles.levelText, { color: colors.foreground }]}>
                    {MASTERY_LABELS[level]}
                  </Text>
                </View>
                <View style={styles.levelProgress}>
                  <ProgressBar
                    progress={percent}
                    color={masteryColor(level)}
                    trackColor={colors.muted}
                  />
                </View>
                <Text style={[styles.levelCount, { color: colors.mutedForeground }]}>
                  {count}
                </Text>
              </View>
            );
          })}
          <View style={styles.masteryRow}>
            <View style={styles.masteryLabel}>
              <View style={[styles.levelDot, { backgroundColor: colors.mutedForeground }]} />
              <Text style={[styles.levelText, { color: colors.foreground }]}>Chưa ôn</Text>
            </View>
            <View style={styles.levelProgress}>
              <ProgressBar
                progress={words.length ? ((words.length - learnedCount) / words.length) * 100 : 0}
                color={colors.mutedForeground}
                trackColor={colors.muted}
              />
            </View>
            <Text style={[styles.levelCount, { color: colors.mutedForeground }]}>
              {words.length - learnedCount}
            </Text>
          </View>
        </View>
      </Panel>

      <Text style={[styles.footerNote, { color: colors.mutedForeground }]}>
        Tổng cộng {reviews.length} lượt đánh giá đã được lưu trên thiết bị này.
      </Text>
    </AppPage>
  );
}

const styles = StyleSheet.create({
  todayPanel: { gap: 14 },
  todayHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  panelEyebrow: { fontSize: 10, letterSpacing: 1.1, fontFamily: 'Inter_700Bold' },
  todayCount: { marginTop: 5, fontSize: 32, fontFamily: 'Inter_700Bold' },
  todayUnit: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  targetIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  helper: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  summaryRow: { flexDirection: 'row', gap: 9 },
  summaryCard: { flex: 1, minHeight: 91, padding: 12, gap: 4, justifyContent: 'center' },
  summaryNumber: { fontSize: 21, fontFamily: 'Inter_700Bold' },
  summaryLabel: { fontSize: 10, lineHeight: 15, fontFamily: 'Inter_500Medium' },
  sectionTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
  chart: { height: 136, flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', paddingTop: 8, gap: 8 },
  chartDay: { flex: 1, height: 126, alignItems: 'center', justifyContent: 'flex-end', gap: 5 },
  chartCount: { height: 14, fontSize: 10, fontFamily: 'Inter_500Medium' },
  chartTrack: { width: '100%', height: 90, alignItems: 'center', justifyContent: 'flex-end' },
  chartBar: { width: '58%', minHeight: 4, borderRadius: 7 },
  chartLabel: { fontSize: 10, fontFamily: 'Inter_500Medium' },
  masteryHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  masteryTitleBlock: { gap: 4 },
  masteryList: { gap: 14, paddingTop: 5 },
  masteryRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  masteryLabel: { width: 80, flexDirection: 'row', alignItems: 'center', gap: 7 },
  levelDot: { width: 8, height: 8, borderRadius: 4 },
  levelText: { fontSize: 11, fontFamily: 'Inter_500Medium' },
  levelProgress: { flex: 1 },
  levelCount: { width: 21, textAlign: 'right', fontSize: 11, fontFamily: 'Inter_600SemiBold' },
  footerNote: { fontSize: 11, lineHeight: 17, textAlign: 'center', fontFamily: 'Inter_400Regular' },
});
