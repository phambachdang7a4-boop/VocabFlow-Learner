import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import {
  RATING_LABELS,
  nextIntervalDays,
  type ReviewRating,
  type VocabularyWord,
} from '@/constants/vocabulary';
import {
  ActionButton,
  AppPage,
  Panel,
  ProgressBar,
  ScreenTitle,
} from '@/components/VocabUI';

const ratingOrder: ReviewRating[] = [1, 2, 3, 4, 5];
const intervals = ['10 phút', '10 phút', '1 ngày', '1 ngày', '1 ngày'];

function getRatingColor(rating: ReviewRating, colors: ReturnType<typeof useColors>) {
  if (rating <= 2) return colors.destructive;
  if (rating === 3) return colors.accentForeground;
  return colors.secondaryForeground;
}

export default function LearnScreen() {
  const colors = useColors();
  const { words, recordReview, isHydrated } = useVocab();
  const dueWords = useMemo(
    () =>
      words
        .filter((word) => word.nextReviewAt <= Date.now())
        .sort((a, b) => a.nextReviewAt - b.nextReviewAt),
    [words],
  );
  const [sessionIds, setSessionIds] = useState<string[]>([]);
  const [cardIndex, setCardIndex] = useState(0);
  const [isRevealed, setIsRevealed] = useState(false);

  useEffect(() => {
    if (isHydrated && sessionIds.length === 0 && dueWords.length > 0) {
      setSessionIds(dueWords.map((word) => word.id));
      setCardIndex(0);
    }
  }, [isHydrated, dueWords, sessionIds.length]);

  const currentId = sessionIds[cardIndex];
  const currentWord: VocabularyWord | undefined = words.find(
    (word) => word.id === currentId,
  );
  const finished = sessionIds.length > 0 && cardIndex >= sessionIds.length;
  const isEmpty = !currentWord || finished;

  function startFreshSession() {
    setSessionIds(dueWords.map((word) => word.id));
    setCardIndex(0);
    setIsRevealed(false);
  }

  function rate(rating: ReviewRating) {
    if (!currentWord) return;
    recordReview(currentWord.id, rating);
    void Haptics.selectionAsync();
    setIsRevealed(false);
    setCardIndex((current) => current + 1);
  }

  function intervalLabel(rating: ReviewRating) {
    if (!currentWord) return intervals[rating - 1];
    const days = nextIntervalDays(currentWord, rating);
    if (days < 1) return '10 phút';
    return `${Math.max(1, Math.round(days))} ngày`;
  }

  return (
    <AppPage>
      <ScreenTitle
        title="Ôn tập"
        subtitle="Nhớ lâu hơn với những lần gặp lại đúng lúc."
      />

      {!isHydrated ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} />
          <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
            Đang mở bộ từ của bạn…
          </Text>
        </View>
      ) : currentWord ? (
        <>
          <View style={styles.sessionMeta}>
            <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
              Thẻ {cardIndex + 1} / {sessionIds.length}
            </Text>
            <Text style={[styles.helperText, { color: colors.mutedForeground }]}>
              {dueWords.length} từ đến hạn
            </Text>
          </View>
          <ProgressBar
            progress={(cardIndex / Math.max(1, sessionIds.length)) * 100}
          />

          <Pressable
            accessibilityRole="button"
            accessibilityLabel={isRevealed ? 'Ẩn đáp án' : 'Lật thẻ xem đáp án'}
            testID="flashcard"
            onPress={() => {
              setIsRevealed((revealed) => !revealed);
              void Haptics.selectionAsync();
            }}
            style={({ pressed }) => [
              styles.flashCard,
              {
                backgroundColor: isRevealed ? colors.secondary : colors.card,
                borderColor: isRevealed ? colors.secondary : colors.border,
                opacity: pressed ? 0.92 : 1,
              },
            ]}
          >
            <View style={styles.cardLabel}>
              <Feather
                name={isRevealed ? 'check-circle' : 'layers'}
                size={16}
                color={isRevealed ? colors.secondaryForeground : colors.primary}
              />
              <Text
                style={[
                  styles.cardEyebrow,
                  { color: isRevealed ? colors.secondaryForeground : colors.mutedForeground },
                ]}
              >
                {isRevealed ? 'ĐÁP ÁN' : 'TỪ TIẾNG ANH'}
              </Text>
            </View>
            {!isRevealed ? (
              <View style={styles.frontContent}>
                <Text style={[styles.englishWord, { color: colors.foreground }]}>
                  {currentWord.english}
                </Text>
                {currentWord.phonetic ? (
                  <Text style={[styles.phonetic, { color: colors.mutedForeground }]}>
                    {currentWord.phonetic}
                  </Text>
                ) : null}
                <Text style={[styles.tapHint, { color: colors.mutedForeground }]}>
                  Chạm vào thẻ để xem nghĩa
                </Text>
              </View>
            ) : (
              <View style={styles.answerContent}>
                <Text style={[styles.meaning, { color: colors.foreground }]}>
                  {currentWord.meaning}
                </Text>
                {currentWord.phonetic ? (
                  <Text style={[styles.phonetic, { color: colors.mutedForeground }]}>
                    {currentWord.phonetic}
                  </Text>
                ) : null}
                {currentWord.example || currentWord.exampleTranslation ? (
                  <View style={[styles.exampleBox, { borderTopColor: colors.border }]}>
                    {currentWord.example ? (
                      <Text style={[styles.example, { color: colors.foreground }]}>
                        “{currentWord.example}”
                      </Text>
                    ) : null}
                    {currentWord.exampleTranslation ? (
                      <Text style={[styles.exampleTranslation, { color: colors.mutedForeground }]}>
                        {currentWord.exampleTranslation}
                      </Text>
                    ) : null}
                  </View>
                ) : (
                  <Text style={[styles.exampleTranslation, { color: colors.mutedForeground }]}>
                    Chưa có câu ví dụ cho từ này.
                  </Text>
                )}
              </View>
            )}
          </Pressable>

          {isRevealed ? (
            <View style={styles.ratingArea}>
              <Text style={[styles.ratingTitle, { color: colors.foreground }]}>
                Bạn nhớ từ này thế nào?
              </Text>
              <View style={styles.ratingRow}>
                {ratingOrder.map((rating) => {
                  const tone = getRatingColor(rating, colors);
                  return (
                    <Pressable
                      key={rating}
                      accessibilityRole="button"
                      accessibilityLabel={`Mức ${rating}: ${RATING_LABELS[rating]}`}
                      testID={`rating-${rating}`}
                      onPress={() => rate(rating)}
                      style={({ pressed }) => [
                        styles.ratingButton,
                        {
                          backgroundColor: colors.card,
                          borderColor: colors.border,
                          opacity: pressed ? 0.68 : 1,
                        },
                      ]}
                    >
                      <Text style={[styles.ratingNumber, { color: tone }]}>{rating}</Text>
                      <Text style={[styles.ratingLabel, { color: colors.foreground }]}>
                        {RATING_LABELS[rating]}
                      </Text>
                      <Text style={[styles.intervalLabel, { color: colors.mutedForeground }]}>
                        {intervalLabel(rating)}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </View>
          ) : (
            <Text style={[styles.helperText, styles.center, { color: colors.mutedForeground }]}>
              Hãy thử nhớ nghĩa trước khi lật thẻ.
            </Text>
          )}
        </>
      ) : (
        <Panel style={styles.emptyPanel}>
          <View style={[styles.doneIcon, { backgroundColor: colors.secondary }]}>
            <Feather
              name={finished ? 'check' : 'clock'}
              size={24}
              color={colors.secondaryForeground}
            />
          </View>
          <Text style={[styles.doneTitle, { color: colors.foreground }]}>
            {finished
              ? 'Bạn đã hoàn thành lượt ôn'
              : words.length
                ? 'Hôm nay chưa có từ đến hạn'
                : 'Bắt đầu bằng từ đầu tiên'}
          </Text>
          <Text style={[styles.doneCopy, { color: colors.mutedForeground }]}>
            {finished
              ? 'Các thẻ vừa ôn đã được lên lịch cho lần gặp tiếp theo.'
              : words.length
                ? 'Từ vựng sẽ quay lại theo lịch lặp lại ngắt quãng.'
                : 'Thêm một từ tiếng Anh để tạo thẻ ghi nhớ đầu tiên.'}
          </Text>
          {finished && dueWords.length > 0 ? (
            <ActionButton
              label="Ôn lượt mới"
              icon="rotate-ccw"
              kind="secondary"
              onPress={startFreshSession}
            />
          ) : !words.length ? (
            <ActionButton
              label="Thêm từ vựng"
              icon="plus"
              onPress={() => router.push('/word-form')}
            />
          ) : null}
          {dueWords.length > 0 && !finished ? (
            <ActionButton
              label="Tải lại thẻ đến hạn"
              icon="rotate-ccw"
              kind="outline"
              onPress={startFreshSession}
            />
          ) : null}
        </Panel>
      )}
    </AppPage>
  );
}

const styles = StyleSheet.create({
  loading: { minHeight: 240, alignItems: 'center', justifyContent: 'center', gap: 12 },
  helperText: { fontSize: 13, lineHeight: 19, fontFamily: 'Inter_400Regular' },
  sessionMeta: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  flashCard: { minHeight: 340, borderRadius: 26, borderWidth: 1, padding: 22, justifyContent: 'space-between', gap: 20 },
  cardLabel: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  cardEyebrow: { fontSize: 10, letterSpacing: 1.1, fontFamily: 'Inter_700Bold' },
  frontContent: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  englishWord: { fontSize: 34, lineHeight: 42, textAlign: 'center', fontFamily: 'Inter_700Bold' },
  phonetic: { fontSize: 15, fontFamily: 'Inter_400Regular' },
  tapHint: { marginTop: 18, fontSize: 12, fontFamily: 'Inter_400Regular' },
  answerContent: { flex: 1, justifyContent: 'center', gap: 9 },
  meaning: { fontSize: 25, lineHeight: 34, fontFamily: 'Inter_700Bold' },
  exampleBox: { marginTop: 14, paddingTop: 17, borderTopWidth: 1, gap: 9 },
  example: { fontSize: 15, lineHeight: 23, fontFamily: 'Inter_500Medium' },
  exampleTranslation: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  ratingArea: { gap: 11 },
  ratingTitle: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  ratingRow: { flexDirection: 'row', gap: 6 },
  ratingButton: { flex: 1, minHeight: 83, borderWidth: 1, borderRadius: 14, paddingHorizontal: 3, paddingVertical: 8, alignItems: 'center', justifyContent: 'center', gap: 3 },
  ratingNumber: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  ratingLabel: { fontSize: 9, textAlign: 'center', fontFamily: 'Inter_600SemiBold' },
  intervalLabel: { fontSize: 8, textAlign: 'center', fontFamily: 'Inter_400Regular' },
  center: { textAlign: 'center' },
  emptyPanel: { alignItems: 'center', paddingVertical: 28 },
  doneIcon: { width: 56, height: 56, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  doneTitle: { fontSize: 19, lineHeight: 26, textAlign: 'center', fontFamily: 'Inter_700Bold' },
  doneCopy: { fontSize: 14, lineHeight: 21, textAlign: 'center', fontFamily: 'Inter_400Regular' },
});
