import React from 'react';
import { Platform, StyleSheet } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const isWeb = Platform.OS === 'web';
  const tabHeight = isWeb ? 84 : 62 + insets.bottom;

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: true,
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        tabBarHideOnKeyboard: true,
        tabBarStyle: {
          height: tabHeight,
          paddingTop: 7,
          paddingBottom: isWeb ? 34 : Math.max(insets.bottom, 5),
          backgroundColor: colors.background,
          borderTopColor: colors.border,
          borderTopWidth: StyleSheet.hairlineWidth,
          elevation: 0,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          fontFamily: 'Inter_500Medium',
          marginTop: 1,
        },
        tabBarIconStyle: { marginTop: 1 },
        sceneStyle: { backgroundColor: colors.background },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Trang chủ',
          tabBarIcon: ({ focused, size }) => <Feather name="home" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
      <Tabs.Screen
        name="learn"
        options={{
          title: 'Học',
          tabBarIcon: ({ focused, size }) => <Feather name="layers" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
      <Tabs.Screen
        name="dictionary"
        options={{
          title: 'Từ điển',
          tabBarIcon: ({ focused, size }) => <Feather name="search" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
      <Tabs.Screen
        name="vocabulary"
        options={{
          title: 'Từ vựng',
          tabBarIcon: ({ focused, size }) => <Feather name="book-open" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
      <Tabs.Screen
        name="statistics"
        options={{
          title: 'Thống kê',
          tabBarIcon: ({ focused, size }) => <Feather name="bar-chart-2" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Cài đặt',
          tabBarIcon: ({ focused, size }) => <Feather name="settings" size={size} color={focused ? colors.primary : colors.mutedForeground} />,
        }}
      />
    </Tabs>
  );
}
