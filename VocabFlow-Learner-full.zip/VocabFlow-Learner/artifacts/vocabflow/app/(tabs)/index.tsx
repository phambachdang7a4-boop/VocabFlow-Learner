import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import { isSameLocalDay } from '@/constants/vocabulary';
import {
  ActionButton,
  AppPage,
  IconButton,
  MasteryBadge,
  Panel,
  ProgressBar,
  SectionHeading,
} from '@/components/VocabUI';

function greetingForHour(hour: number) {
  if (hour < 12) return 'Chào buổi sáng';
  if (hour < 18) return 'Chào buổi chiều';
  return 'Chào buổi tối';
}

export default function HomeScreen() {
  const colors = useColors();
  const { words, reviews, dailyGoal, isHydrated } = useVocab();
  const now = Date.now();
  const todayReviews = reviews.filter((review) =>
    isSameLocalDay(review.reviewedAt, now),
  ).length;
  const dueCount = words.filter((word) => word.nextReviewAt <= now).length;
  const progress = Math.min(100, (todayReviews / dailyGoal) * 100);
  const recentWords = [...words].sort((a, b) => b.createdAt - a.createdAt).slice(0, 3);
  const dateLabel = new Intl.DateTimeFormat('vi-VN', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  }).format(new Date());

  return (
    <AppPage>
      <View style={styles.topLine}>
        <View style={[styles.brandMark, { backgroundColor: colors.primary }]}>
          <Feather name="book-open" size={19} color={colors.primaryForeground} />
        </View>
        <View style={styles.brandText}>
          <Text style={[styles.brandName, { color: colors.foreground }]}>VocabFlow</Text>
          <Text style={[styles.dateText, { color: colors.mutedForeground }]}>
            {dateLabel}
          </Text>
        </View>
        <IconButton
          icon="plus"
          label="Thêm từ mới"
          testID="home-add-word"
          onPress={() => router.push('/word-form')}
          color={colors.primary}
        />
      </View>

      <View>
        <Text style={[styles.greeting, { color: colors.foreground }]}>
          {greetingForHour(new Date().getHours())}
        </Text>
        <Text style={[styles.tagline, { color: colors.mutedForeground }]}>
          Mỗi ngày một chút, tiếng Anh tiến xa hơn.
        </Text>
      </View>

      <View style={[styles.hero, { backgroundColor: colors.primary }]}>
        <View style={styles.heroTop}>
          <View style={[styles.heroIcon, { backgroundColor: colors.accent }]}>
            <Feather name="layers" size={18} color={colors.primary} />
          </View>
          <Text style={[styles.heroEyebrow, { color: colors.primaryForeground }]}>
            NHỊP HỌC HÔM NAY
          </Text>
        </View>
        <Text style={[styles.heroTitle, { color: colors.primaryForeground }]}>
          {dueCount > 0 ? `${dueCount} từ đang chờ bạn` : 'Giữ nhịp học mỗi ngày'}
        </Text>
        <Text style={[styles.heroCopy, { color: colors.primaryForeground }]}>
          {todayReviews} / {dailyGoal} lượt ôn đã hoàn thành
        </Text>
        <ProgressBar
          progress={progress}
          color={colors.primaryForeground}
          trackColor={colors.accent}
        />
        <ActionButton
          label={dueCount > 0 ? 'Bắt đầu ôn tập' : 'Mở thẻ từ vựng'}
          icon="arrow-right"
          onPress={() => router.push('/learn')}
          kind="secondary"
          testID="home-start-learning"
        />
      </View>

      <View style={styles.statsRow}>
        <Panel style={styles.statPanel}>
          <View style={[styles.statIcon, { backgroundColor: colors.secondary }]}>
            <Feather name="book" size={17} color={colors.secondaryForeground} />
          </View>
          <Text style={[styles.statNumber, { color: colors.foreground }]}>
            {isHydrated ? words.length : '—'}
          </Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>
            từ đã lưu
          </Text>
        </Panel>
        <Panel style={styles.statPanel}>
          <View style={[styles.statIcon, { backgroundColor: colors.accent }]}>
            <Feather name="check-circle" size={17} color={colors.accentForeground} />
          </View>
          <Text style={[styles.statNumber, { color: colors.foreground }]}>
            {todayReviews}
          </Text>
          <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>
            lượt ôn hôm nay
          </Text>
        </Panel>
      </View>

      <SectionHeading
        title="Từ mới gần đây"
        action={
          <Pressable
            accessibilityRole="button"
            onPress={() => router.push('/vocabulary')}
            style={({ pressed }) => ({ opacity: pressed ? 0.6 : 1 })}
          >
            <Text style={[styles.linkText, { color: colors.primary }]}>Xem tất cả</Text>
          </Pressable>
        }
      />

      {recentWords.length ? (
        <View style={styles.wordList}>
          {recentWords.map((word) => (
            <Pressable
              key={word.id}
              accessibilityRole="button"
              onPress={() =>
                router.push({ pathname: '/word-form', params: { wordId: word.id } })
              }
              style={({ pressed }) => [
                styles.recentWord,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  opacity: pressed ? 0.8 : 1,
                },
              ]}
            >
              <View style={styles.recentWordText}>
                <Text style={[styles.recentEnglish, { color: colors.foreground }]}>
                  {word.english}
                </Text>
                <Text style={[styles.recentMeaning, { color: colors.mutedForeground }]}>
                  {word.meaning}
                </Text>
              </View>
              <MasteryBadge level={word.masteryLevel} />
            </Pressable>
          ))}
        </View>
      ) : (
        <Panel>
          <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
            Chưa có từ nào trong sổ
          </Text>
          <Text style={[styles.dateText, { color: colors.mutedForeground }]}>
            Thêm từ đầu tiên để bắt đầu tạo nhịp học của riêng bạn.
          </Text>
          <ActionButton
            label="Thêm từ vựng"
            icon="plus"
            onPress={() => router.push('/word-form')}
          />
        </Panel>
      )}
    </AppPage>
  );
}

const styles = StyleSheet.create({
  topLine: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  brandMark: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  brandText: { flex: 1, gap: 2 },
  brandName: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  dateText: { fontSize: 12, fontFamily: 'Inter_400Regular', lineHeight: 18 },
  greeting: { fontSize: 27, lineHeight: 34, fontFamily: 'Inter_700Bold' },
  tagline: { marginTop: 4, fontSize: 14, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  hero: { borderRadius: 25, padding: 20, gap: 13 },
  heroTop: { flexDirection: 'row', alignItems: 'center', gap: 9 },
  heroIcon: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  heroEyebrow: { fontSize: 10, letterSpacing: 1.1, fontFamily: 'Inter_700Bold' },
  heroTitle: { fontSize: 22, lineHeight: 29, fontFamily: 'Inter_700Bold' },
  heroCopy: { fontSize: 13, fontFamily: 'Inter_500Medium' },
  statsRow: { flexDirection: 'row', gap: 12 },
  statPanel: { flex: 1, minHeight: 125, gap: 7 },
  statIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  statNumber: { fontSize: 25, fontFamily: 'Inter_700Bold' },
  statLabel: { fontSize: 12, fontFamily: 'Inter_500Medium' },
  linkText: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  wordList: { gap: 9 },
  recentWord: { minHeight: 67, borderWidth: 1, borderRadius: 17, paddingHorizontal: 14, paddingVertical: 11, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  recentWordText: { flex: 1, gap: 3 },
  recentEnglish: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  recentMeaning: { fontSize: 12, fontFamily: 'Inter_400Regular' },
  emptyTitle: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
});
