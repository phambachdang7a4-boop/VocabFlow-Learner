import React, { useState } from 'react';
import {
  ActivityIndicator,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { useColors } from '@/hooks/useColors';
import { useVocab } from '@/contexts/VocabContext';
import type { VocabularyInput, VocabularyWord } from '@/constants/vocabulary';

function WordFormFields({ word }: { word?: VocabularyWord }) {
  const colors = useColors();
  const { addWord, updateWord, wordLimit } = useVocab();
  const [english, setEnglish] = useState(word?.english ?? '');
  const [meaning, setMeaning] = useState(word?.meaning ?? '');
  const [phonetic, setPhonetic] = useState(word?.phonetic ?? '');
  const [example, setExample] = useState(word?.example ?? '');
  const [exampleTranslation, setExampleTranslation] = useState(
    word?.exampleTranslation ?? '',
  );
  const [error, setError] = useState('');

  function saveWord() {
    if (!english.trim() || !meaning.trim()) {
      setError('Vui lòng điền từ và nghĩa tiếng Việt.');
      return;
    }
    const input: VocabularyInput = {
      english: english.trim(),
      meaning: meaning.trim(),
      phonetic: phonetic.trim() || undefined,
      example: example.trim(),
      exampleTranslation: exampleTranslation.trim(),
    };
    if (word) updateWord(word.id, input);
    else if (addWord(input) === null) {
      setError(`Bản Free chỉ lưu tối đa ${wordLimit} từ. Hãy nâng cấp Premium để thêm từ mới.`);
      return;
    }
    router.back();
  }

  return (
    <>
      <KeyboardAwareScrollViewCompat
        style={styles.flex}
        contentContainerStyle={styles.formContent}
        bottomOffset={32}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.intro, { color: colors.mutedForeground }]}>
          Thêm ngữ cảnh để bạn dễ nhớ và dùng từ đúng hơn.
        </Text>
        <Field
          label="Từ tiếng Anh"
          placeholder="Ví dụ: curious"
          value={english}
          onChangeText={setEnglish}
          autoCapitalize="none"
          testID="word-english"
        />
        <Field
          label="Nghĩa tiếng Việt"
          placeholder="Ví dụ: tò mò, ham tìm hiểu"
          value={meaning}
          onChangeText={setMeaning}
          testID="word-meaning"
        />
        <Field
          label="Phiên âm"
          placeholder="Không bắt buộc — ví dụ: /ˈkjʊriəs/"
          value={phonetic}
          onChangeText={setPhonetic}
          autoCapitalize="none"
          testID="word-phonetic"
        />
        <Field
          label="Câu ví dụ tiếng Anh (không bắt buộc)"
          placeholder="Ví dụ: She is curious about languages."
          value={example}
          onChangeText={setExample}
          multiline
          testID="word-example"
        />
        <Field
          label="Bản dịch câu ví dụ (không bắt buộc)"
          placeholder="Nhập bản dịch nếu có."
          value={exampleTranslation}
          onChangeText={setExampleTranslation}
          multiline
          testID="word-translation"
        />
        {error ? (
          <Text accessibilityRole="alert" style={[styles.errorText, { color: colors.destructive }]}>
            {error}
          </Text>
        ) : null}
        <Pressable
          accessibilityRole="button"
          testID="word-save"
          onPress={saveWord}
          style={({ pressed }) => [
            styles.saveButton,
            { backgroundColor: colors.primary, opacity: pressed ? 0.82 : 1 },
          ]}
        >
          <Feather name="check" size={18} color={colors.primaryForeground} />
          <Text style={[styles.saveText, { color: colors.primaryForeground }]}>
            {word ? 'Lưu thay đổi' : 'Lưu từ vựng'}
          </Text>
        </Pressable>
      </KeyboardAwareScrollViewCompat>
    </>
  );
}

function Field({
  label,
  placeholder,
  value,
  onChangeText,
  multiline,
  autoCapitalize,
  testID,
}: {
  label: string;
  placeholder: string;
  value: string;
  onChangeText: (value: string) => void;
  multiline?: boolean;
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
  testID: string;
}) {
  const colors = useColors();
  return (
    <View style={styles.fieldGroup}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
      <TextInput
        accessibilityLabel={label}
        testID={testID}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={colors.mutedForeground}
        autoCapitalize={autoCapitalize ?? 'sentences'}
        multiline={multiline}
        textAlignVertical={multiline ? 'top' : 'center'}
        returnKeyType={multiline ? 'default' : 'next'}
        style={[
          styles.input,
          {
            backgroundColor: colors.card,
            borderColor: colors.border,
            color: colors.foreground,
            minHeight: multiline ? 92 : 52,
          },
        ]}
      />
    </View>
  );
}

export default function WordFormScreen() {
  const colors = useColors();
  const { wordId } = useLocalSearchParams<{ wordId?: string }>();
  const { words, isHydrated } = useVocab();
  const word = wordId ? words.find((item) => item.id === wordId) : undefined;

  return (
    <SafeAreaView
      edges={['top', 'bottom']}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <View style={styles.modalHeader}>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Đóng"
          onPress={() => router.back()}
          hitSlop={10}
          style={({ pressed }) => [styles.closeButton, { opacity: pressed ? 0.6 : 1 }]}
        >
          <Feather name="x" size={21} color={colors.foreground} />
        </Pressable>
        <Text style={[styles.modalTitle, { color: colors.foreground }]}>
          {wordId ? 'Sửa từ vựng' : 'Từ mới'}
        </Text>
        <View style={styles.closeButton} />
      </View>
      {!isHydrated ? (
        <View style={styles.loading}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : wordId && !word ? (
        <View style={styles.loading}>
          <Text style={[styles.intro, { color: colors.mutedForeground }]}>
            Không tìm thấy từ này.
          </Text>
        </View>
      ) : (
        <WordFormFields key={wordId ?? 'new'} word={word} />
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  screen: { flex: 1 },
  modalHeader: { minHeight: 54, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 18 },
  closeButton: { width: 34, height: 34, alignItems: 'center', justifyContent: 'center' },
  modalTitle: { fontSize: 16, fontFamily: 'Inter_700Bold' },
  formContent: { paddingHorizontal: 20, paddingTop: 5, paddingBottom: 30, gap: 17 },
  intro: { fontSize: 13, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  fieldGroup: { gap: 7 },
  fieldLabel: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  input: { borderWidth: 1, borderRadius: 15, paddingHorizontal: 14, paddingVertical: 13, fontSize: 14, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  errorText: { fontSize: 12, lineHeight: 18, fontFamily: 'Inter_500Medium' },
  saveButton: { minHeight: 52, borderRadius: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, marginTop: 3 },
  saveText: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
});
