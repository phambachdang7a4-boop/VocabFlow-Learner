import React from 'react';
import type { ReactNode } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { MASTERY_LABELS, type VocabularyWord } from '@/constants/vocabulary';

export function AppPage({ children }: { children: ReactNode }) {
  const colors = useColors();
  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.flex, { backgroundColor: colors.background }]}
    >
      <ScrollView
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={styles.pageContent}
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function ScreenTitle({
  title,
  subtitle,
  trailing,
}: {
  title: string;
  subtitle?: string;
  trailing?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.titleRow}>
      <View style={styles.flex}>
        <Text style={[styles.pageTitle, { color: colors.foreground }]}>{title}</Text>
        {subtitle ? (
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
            {subtitle}
          </Text>
        ) : null}
      </View>
      {trailing}
    </View>
  );
}

export function Panel({
  children,
  style,
}: {
  children: ReactNode;
  style?: object;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.panel,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          borderRadius: colors.radius + 12,
        },
        style,
      ]}
    >
      {children}
    </View>
  );
}

export function ActionButton({
  label,
  onPress,
  icon,
  kind = 'primary',
  disabled = false,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: React.ComponentProps<typeof Feather>['name'];
  kind?: 'primary' | 'secondary' | 'outline';
  disabled?: boolean;
  testID?: string;
}) {
  const colors = useColors();
  const backgroundColor =
    kind === 'primary'
      ? colors.primary
      : kind === 'secondary'
        ? colors.secondary
        : 'transparent';
  const foregroundColor =
    kind === 'primary'
      ? colors.primaryForeground
      : kind === 'secondary'
        ? colors.secondaryForeground
        : colors.foreground;
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      testID={testID}
      onPress={onPress}
      disabled={disabled}
      style={({ pressed }) => [
        styles.actionButton,
        {
          backgroundColor,
          borderColor: colors.border,
          borderWidth: kind === 'outline' ? 1 : 0,
          opacity: disabled ? 0.48 : pressed ? 0.82 : 1,
        },
      ]}
    >
      {icon ? <Feather name={icon} size={17} color={foregroundColor} /> : null}
      <Text style={[styles.actionButtonText, { color: foregroundColor }]}>
        {label}
      </Text>
    </Pressable>
  );
}

export function IconButton({
  icon,
  label,
  onPress,
  testID,
  color,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  label: string;
  onPress: () => void;
  testID?: string;
  color?: string;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={label}
      testID={testID}
      onPress={onPress}
      hitSlop={10}
      style={({ pressed }) => [styles.iconButton, { opacity: pressed ? 0.55 : 1 }]}
    >
      <Feather name={icon} size={20} color={color ?? colors.foreground} />
    </Pressable>
  );
}

export function WordRow({
  word,
  onPress,
  onDelete,
}: {
  word: VocabularyWord;
  onPress: () => void;
  onDelete?: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      accessibilityRole="button"
      onPress={onPress}
      style={({ pressed }) => [
        styles.wordRow,
        {
          backgroundColor: colors.card,
          borderColor: colors.border,
          opacity: pressed ? 0.82 : 1,
        },
      ]}
    >
      <View style={styles.wordText}>
        <Text style={[styles.wordEnglish, { color: colors.foreground }]}>
          {word.english}
        </Text>
        <Text style={[styles.wordMeaning, { color: colors.mutedForeground }]}>
          {word.meaning}
        </Text>
      </View>
      <View style={styles.wordEnd}>
        <MasteryBadge level={word.masteryLevel} />
        {onDelete ? (
          <IconButton
            icon="trash-2"
            label={`Xóa từ ${word.english}`}
            onPress={onDelete}
            color={colors.destructive}
          />
        ) : (
          <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
        )}
      </View>
    </Pressable>
  );
}

export function MasteryBadge({ level }: { level: number }) {
  const colors = useColors();
  const label = MASTERY_LABELS[level] ?? `Cấp ${level}`;
  const textColor =
    level === 0
      ? colors.mutedForeground
      : level >= 4
        ? colors.secondaryForeground
        : colors.accentForeground;
  const backgroundColor =
    level === 0
      ? colors.muted
      : level >= 4
        ? colors.secondary
        : colors.accent;
  return (
    <View style={[styles.badge, { backgroundColor }]}>
      <Text style={[styles.badgeText, { color: textColor }]}>{label}</Text>
    </View>
  );
}

export function SectionHeading({
  title,
  action,
}: {
  title: string;
  action?: ReactNode;
}) {
  const colors = useColors();
  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>{title}</Text>
      {action}
    </View>
  );
}

export function ProgressBar({
  progress,
  color,
  trackColor,
}: {
  progress: number;
  color?: string;
  trackColor?: string;
}) {
  const colors = useColors();
  return (
    <View
      style={[
        styles.progressTrack,
        { backgroundColor: trackColor ?? colors.muted },
      ]}
    >
      <View
        style={[
          styles.progressFill,
          {
            width: `${Math.max(0, Math.min(100, progress))}%`,
            backgroundColor: color ?? colors.primary,
          },
        ]}
      />
    </View>
  );
}

export const uiStyles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center' },
  spaceBetween: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  gap8: { gap: 8 },
  gap12: { gap: 12 },
  gap16: { gap: 16 },
  mutedText: { fontSize: 13, lineHeight: 19 },
  label: { fontSize: 12, fontFamily: 'Inter_600SemiBold', letterSpacing: 0.3 },
});

const styles = StyleSheet.create({
  flex: { flex: 1 },
  pageContent: { paddingHorizontal: 20, paddingTop: 16, paddingBottom: 32, gap: 20 },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  pageTitle: { fontSize: 27, lineHeight: 34, fontFamily: 'Inter_700Bold' },
  subtitle: { marginTop: 4, fontSize: 14, lineHeight: 20, fontFamily: 'Inter_400Regular' },
  panel: { borderWidth: 1, padding: 16, gap: 12 },
  actionButton: { minHeight: 48, paddingHorizontal: 16, borderRadius: 15, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 9 },
  actionButtonText: { fontSize: 14, fontFamily: 'Inter_600SemiBold' },
  iconButton: { minWidth: 28, minHeight: 32, alignItems: 'center', justifyContent: 'center' },
  wordRow: { minHeight: 72, borderWidth: 1, borderRadius: 18, paddingHorizontal: 14, paddingVertical: 12, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  wordText: { flex: 1, gap: 4 },
  wordEnglish: { fontSize: 16, fontFamily: 'Inter_600SemiBold' },
  wordMeaning: { fontSize: 13, lineHeight: 18, fontFamily: 'Inter_400Regular' },
  wordEnd: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  badge: { borderRadius: 20, paddingHorizontal: 9, paddingVertical: 5 },
  badgeText: { fontSize: 10, fontFamily: 'Inter_600SemiBold' },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  sectionTitle: { fontSize: 17, fontFamily: 'Inter_600SemiBold' },
  progressTrack: { height: 8, borderRadius: 8, overflow: 'hidden' },
  progressFill: { height: 8, borderRadius: 8 },
});
