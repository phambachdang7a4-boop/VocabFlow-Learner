import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { ReactNode } from 'react';
import {
  createDictionaryWord,
  findExistingWord,
  FREE_WORD_LIMIT,
  makeId,
  nextIntervalDays,
  nextStep,
  type DictionaryVocabularyInput,
  type ReviewRating,
  type ReviewRecord,
  type VocabularyInput,
  type VocabularyWord,
} from '@/constants/vocabulary';

const STORAGE_KEY = '@vocabflow/local-data-v1';
const DAY_IN_MS = 24 * 60 * 60 * 1000;

interface StoredData {
  words: VocabularyWord[];
  reviews: ReviewRecord[];
  dailyGoal: number;
}

interface VocabContextValue extends StoredData {
  isHydrated: boolean;
  persistenceError: string | null;
  isPremium: boolean;
  wordLimit: number;
  canAddWord: boolean;
  addWord: (input: VocabularyInput) => string | null;
  addDictionaryWord: (
    input: DictionaryVocabularyInput,
  ) => { status: 'added' | 'duplicate' | 'limit'; wordId: string };
  updateWord: (id: string, input: VocabularyInput) => void;
  deleteWord: (id: string) => void;
  recordReview: (id: string, rating: ReviewRating) => void;
  setDailyGoal: (goal: number) => void;
}

const VocabContext = createContext<VocabContextValue | null>(null);

function makeEmptyData(): StoredData {
  return { words: [], reviews: [], dailyGoal: 15 };
}

function readStoredData(value: string): StoredData {
  const parsed = JSON.parse(value) as Partial<StoredData>;
  if (!Array.isArray(parsed.words) || !Array.isArray(parsed.reviews)) {
    throw new Error('Dữ liệu đã lưu không đúng định dạng.');
  }
  return {
    words: parsed.words as VocabularyWord[],
    reviews: parsed.reviews as ReviewRecord[],
    dailyGoal:
      typeof parsed.dailyGoal === 'number'
        ? Math.min(50, Math.max(5, parsed.dailyGoal))
        : 15,
  };
}

export function VocabProvider({ children }: { children: ReactNode }) {
  const [data, setData] = useState<StoredData>(makeEmptyData);
  const [isHydrated, setIsHydrated] = useState(false);
  const [persistenceError, setPersistenceError] = useState<string | null>(null);
  const writeQueue = useRef<Promise<void>>(Promise.resolve());

  useEffect(() => {
    let mounted = true;
    async function load() {
      try {
        const raw = await AsyncStorage.getItem(STORAGE_KEY);
        if (!mounted) return;
        if (raw) {
          setData(readStoredData(raw));
        } else {
          setData(makeEmptyData());
        }
      } catch (error) {
        if (!mounted) return;
        setData(makeEmptyData());
        setPersistenceError(
          error instanceof Error
            ? `Không đọc được dữ liệu đã lưu: ${error.message}`
            : 'Không đọc được dữ liệu đã lưu trên thiết bị.',
        );
      } finally {
        if (mounted) setIsHydrated(true);
      }
    }
    void load();
    return () => {
      mounted = false;
    };
  }, []);

  useEffect(() => {
    if (!isHydrated) return;
    const snapshot = JSON.stringify(data);
    writeQueue.current = writeQueue.current
      .then(async () => {
        await AsyncStorage.setItem(STORAGE_KEY, snapshot);
        setPersistenceError(null);
      })
      .catch((error: unknown) => {
        setPersistenceError(
          error instanceof Error
            ? `Không thể lưu dữ liệu: ${error.message}`
            : 'Không thể lưu dữ liệu trên thiết bị.',
        );
      });
  }, [data, isHydrated]);

  // Tạm thời chưa có thanh toán: mọi người dùng là bản Free.
  const isPremium = false;
  const wordLimit = isPremium ? Infinity : FREE_WORD_LIMIT;
  const canAddWord = data.words.length < wordLimit;

  const addWord = useCallback((input: VocabularyInput) => {
    if (data.words.length >= wordLimit) return null;
    const id = makeId();
    const now = Date.now();
    setData((current) => ({
      ...current,
      words: [
        {
          ...input,
          id,
          createdAt: now,
          nextReviewAt: now,
          intervalDays: 0,
          repetitions: 0,
          easeFactor: 2.5,
          masteryLevel: 0,
          reviewCount: 0,
          lastReviewedAt: null,
        },
        ...current.words,
      ],
    }));
    return id;
  }, [data.words.length, wordLimit]);

  const addDictionaryWord = useCallback(
    (input: DictionaryVocabularyInput) => {
      const existing = findExistingWord(data.words, input.english);
      if (existing) {
        return { status: 'duplicate' as const, wordId: existing.id };
      }
      if (data.words.length >= wordLimit) {
        return { status: 'limit' as const, wordId: '' };
      }

      const word = createDictionaryWord(input);
      setData((current) => ({
        ...current,
        words: [word, ...current.words],
      }));
      return { status: 'added' as const, wordId: word.id };
    },
    [data.words, wordLimit],
  );

  const updateWord = useCallback((id: string, input: VocabularyInput) => {
    setData((current) => ({
      ...current,
      words: current.words.map((word) =>
        word.id === id ? { ...word, ...input } : word,
      ),
    }));
  }, []);

  const deleteWord = useCallback((id: string) => {
    setData((current) => ({
      ...current,
      words: current.words.filter((word) => word.id !== id),
    }));
  }, []);

  const recordReview = useCallback((id: string, rating: ReviewRating) => {
    const now = Date.now();
    setData((current) => ({
      ...current,
      words: current.words.map((word) => {
        if (word.id !== id) return word;
        const intervalDays = nextIntervalDays(word, rating);
        return {
          ...word,
          intervalDays,
          nextReviewAt: now + intervalDays * DAY_IN_MS,
          repetitions: rating <= 2 ? 0 : word.repetitions + 1,
          easeFactor: Math.max(1.3, word.easeFactor + (rating - 3) * 0.1),
          masteryLevel: nextStep(word, rating),
          reviewCount: word.reviewCount + 1,
          lastReviewedAt: now,
        };
      }),
      reviews: [
        { wordId: id, rating, reviewedAt: now },
        ...current.reviews,
      ].slice(0, 5000),
    }));
  }, []);

  const setDailyGoal = useCallback((goal: number) => {
    setData((current) => ({
      ...current,
      dailyGoal: Math.min(50, Math.max(5, goal)),
    }));
  }, []);

  const value = useMemo(
    () => ({
      ...data,
      isHydrated,
      persistenceError,
      isPremium,
      wordLimit,
      canAddWord,
      addWord,
      addDictionaryWord,
      updateWord,
      deleteWord,
      recordReview,
      setDailyGoal,
    }),
    [
      data,
      isHydrated,
      persistenceError,
      isPremium,
      wordLimit,
      canAddWord,
      addWord,
      addDictionaryWord,
      updateWord,
      deleteWord,
      recordReview,
      setDailyGoal,
    ],
  );

  return <VocabContext.Provider value={value}>{children}</VocabContext.Provider>;
}

export function useVocab() {
  const context = useContext(VocabContext);
  if (!context) throw new Error('useVocab phải được dùng bên trong VocabProvider.');
  return context;
}
