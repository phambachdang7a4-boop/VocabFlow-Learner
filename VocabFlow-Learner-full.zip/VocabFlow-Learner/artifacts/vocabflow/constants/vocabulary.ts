export type ReviewRating = 1 | 2 | 3 | 4 | 5;

export interface VocabularyWord {
  id: string;
  english: string;
  meaning: string;
  phonetic?: string;
  example: string;
  exampleTranslation: string;
  createdAt: number;
  nextReviewAt: number;
  intervalDays: number;
  repetitions: number;
  easeFactor: number;
  masteryLevel: number;
  reviewCount: number;
  lastReviewedAt: number | null;
  dictionary?: DictionaryWordMetadata;
}

export type VocabularyInput = Pick<
  VocabularyWord,
  'english' | 'meaning' | 'phonetic' | 'example' | 'exampleTranslation'
>;

export interface DictionaryAudioSource {
  ipa?: string;
  accent?: string;
  audioUrl: string;
  sourceUrl: string;
  licenseName: string;
  licenseUrl: string;
}

export interface DictionaryWordMetadata {
  partOfSpeech?: string;
  definition?: string;
  sourceName: string;
  sourceUrls: string[];
  licenseName?: string;
  licenseUrl?: string;
  synonyms?: string[];
  pronunciations?: DictionaryAudioSource[];
}

export type DictionaryVocabularyInput = VocabularyInput & {
  dictionary: DictionaryWordMetadata;
};

export interface ReviewRecord {
  wordId: string;
  rating: ReviewRating;
  reviewedAt: number;
}

export function normalizeEnglishWord(value: string): string {
  return value.trim().toLocaleLowerCase('en');
}

export function findExistingWord(
  words: VocabularyWord[],
  english: string,
): VocabularyWord | undefined {
  const normalized = normalizeEnglishWord(english);
  return words.find((word) => normalizeEnglishWord(word.english) === normalized);
}

export function createDictionaryWord(
  input: DictionaryVocabularyInput,
  now = Date.now(),
): VocabularyWord {
  return {
    ...input,
    id: makeId(),
    createdAt: now,
    nextReviewAt: now,
    intervalDays: 0,
    repetitions: 0,
    easeFactor: 2.5,
    masteryLevel: 0,
    reviewCount: 0,
    lastReviewedAt: null,
  };
}

export const MASTERY_LABELS: Record<number, string> = {
  0: 'Mới',
  1: 'Cấp 1',
  2: 'Cấp 2',
  3: 'Cấp 3',
  4: 'Cấp 4',
  5: 'Cấp 5',
  6: 'Cấp 6',
};

export const RATING_LABELS: Record<ReviewRating, string> = {
  1: 'Chưa nhớ',
  2: 'Khó',
  3: 'Ổn',
  4: 'Dễ',
  5: 'Rất dễ',
};

export function isSameLocalDay(first: number, second: number): boolean {
  const firstDate = new Date(first);
  const secondDate = new Date(second);
  return (
    firstDate.getFullYear() === secondDate.getFullYear() &&
    firstDate.getMonth() === secondDate.getMonth() &&
    firstDate.getDate() === secondDate.getDate()
  );
}

export const FREE_WORD_LIMIT = 100;
export const MAX_STEP = 6;
export const RELEARN_DAYS = 10 / (60 * 24);
// Khoảng cách (ngày) sau khi ôn đúng lần thứ 1, 2, 3, 4, 5, 6:
// lần 2 = ngày 2, lần 3 = ngày 5, lần 4 = ngày 12, lần 5 = ngày 26, lần 6 = sau 30 ngày.
export const REVIEW_GAPS_DAYS = [1, 3, 7, 14, 30, 30];

export function isPassingRating(rating: ReviewRating): boolean {
  return rating >= 3;
}

export function nextStep(word: VocabularyWord, rating: ReviewRating): number {
  if (!isPassingRating(rating)) return 0;
  return Math.min(MAX_STEP, word.masteryLevel + 1);
}

export function nextIntervalDays(
  word: VocabularyWord,
  rating: ReviewRating,
): number {
  const step = nextStep(word, rating);
  if (step === 0) return RELEARN_DAYS;
  return REVIEW_GAPS_DAYS[step - 1];
}

export function makeId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
