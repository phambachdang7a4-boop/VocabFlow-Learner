/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#173D38',
    tint: '#1B897B',

    // Core surfaces
    background: '#F7F5EE',
    foreground: '#173D38',

    // Cards / elevated surfaces
    card: '#FFFEF9',
    cardForeground: '#173D38',

    // Primary action color (buttons, links, active states)
    primary: '#E96B50',
    primaryForeground: '#FFFFFF',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#DCEBE1',
    secondaryForeground: '#24594F',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#ECEDE5',
    mutedForeground: '#718078',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#F3DFA9',
    accentForeground: '#654A1E',

    // Destructive actions (delete, error states)
    destructive: '#C84D46',
    destructiveForeground: '#FFFFFF',

    // Borders and input outlines
    border: '#E5E2D7',
    input: '#DEDCD1',
  },

  dark: {
    text: '#E8F1E6',
    tint: '#77C4B2',
    background: '#132D2A',
    foreground: '#E8F1E6',
    card: '#1B3B36',
    cardForeground: '#E8F1E6',
    primary: '#F08063',
    primaryForeground: '#20352F',
    secondary: '#28534A',
    secondaryForeground: '#DDECE4',
    muted: '#24423C',
    mutedForeground: '#A2B6AA',
    accent: '#D9B665',
    accentForeground: '#332917',
    destructive: '#F17D73',
    destructiveForeground: '#321D1B',
    border: '#34554C',
    input: '#385950',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 16,
};

export default colors;
